//
//  Simple_Login_ProjectApp.swift
//  Simple Login Project
//
//  Created by Hafsa Tazrian on 11/13/24.
//

import SwiftUI

@main
struct Simple_Login_ProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
